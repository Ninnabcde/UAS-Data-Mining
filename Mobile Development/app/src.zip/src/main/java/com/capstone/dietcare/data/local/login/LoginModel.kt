package com.capstone.dietcare.data.local.login

data class LoginModel(
    val isLogin: Boolean,
    val email: String,
    val password: String
)
